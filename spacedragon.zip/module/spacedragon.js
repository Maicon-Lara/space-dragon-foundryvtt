/**
 * Space Dragon — módulo de conteúdo para o sistema Old Dragon 2.
 *
 * O módulo é de compêndios. Este script existe por três motivos, todos de
 * coisas que o compêndio sozinho não resolve:
 *
 *   1. O Space Dragon resolve meia dúzia de coisas em 1d100 com sucesso no
 *      MENOR OU IGUAL. Não é uma fórmula diferente do d20 do Old Dragon 2, é
 *      uma comparação diferente, e nenhum campo da ficha faz isso.
 *
 *   2. Essas porcentagens MUDAM COM O NÍVEL e somam coluna de atributo. A
 *      descrição da habilidade é texto fixo; o painel mostra o número da vez.
 *
 *   3. A ficha do OD2 para no 15º nível e o Space Dragon vai ao 20º.
 *
 * A nomenclatura — Ciência no lugar de Inteligência, CP no lugar de CA, JPR/
 * JPF/JPM no lugar de JPD/JPC/JPS — é trocada NA FICHA, e não no idioma: o
 * `lang` é global, e num mundo que também tenha o módulo Star Wars o Jedi
 * passaria a ver os rótulos do Space Dragon. Ver module/rotulos.js.
 *
 * Nada aqui toca em `system.*`. O módulo não inventa campo no sistema de outra
 * pessoa.
 */

import { abrirTeste, rolar, preparar, TESTES } from "./testes.js";
import { ligarPainel, diagnostico } from "./painel.js";
import { aplicarModificadores, compararEscalas, ordenarHabilidades, aplicarCP, bonusDeCP } from "./atributos.js";
import { rolarPV, rolarCritico, multiplicadorCritico } from "./vitalidade.js";
import { ligarCabecalho, danosMortais } from "./cabecalho.js";
import { ligarGrandezas } from "./poderes.js";
import { abrirOrdem, rolarCriticoTabela } from "./ordem.js";
import { ligarOrdemNaFicha, registrarOpcoes as registrarOpcoesDaOrdem } from "./ordem-ficha.js";
import { registrarTema, ligarTema } from "./tema.js";
import { registrarFicha } from "./ficha.js";
import { ligarRotulos } from "./rotulos.js";
import { ligarDegraus } from "./degraus.js";
import { aplicarJP, rolarJP } from "./jp.js";
import { registrarFichaAmeaca, rolarJPAmeaca, rolarMoral } from "./ameaca.js";
import { abrirDesativar, rolarDesativar } from "./robos.js";
import { abrirReliquia, gerarReliquia, gerarDaCriatura, rolarDefeito } from "./reliquias.js";
import { ligarMental, orcamento, gastar, descansar } from "./mental.js";
import { CRITICOS, FALHAS, CRITICOS_NAVE, FALHAS_NAVE } from "./dados.js";

const ID = "spacedragon";
const NIVEL_MAXIMO = 20;

/**
 * Estende o seletor de nível da ficha até o 20º.
 *
 * `CONFIG.olddragon2e.levels` é um objeto simples que o template lê em
 * `{{selectOptions config.levels}}`. O sistema o preenche de 1 a 15, que é o
 * teto do Old Dragon 2. As tabelas do Space Dragon vão até o 20º, e sem isto
 * não há como sequer selecionar o nível na ficha.
 *
 * As strings "16º" a "20º" vêm do lang deste módulo.
 */
function estendeNiveis() {
  const cfg = CONFIG.olddragon2e?.levels;
  if (!cfg) return console.warn(`${ID} | CONFIG.olddragon2e.levels não existe — nível fica no 15º`);
  for (let n = 16; n <= NIVEL_MAXIMO; n += 1) cfg[n] ??= `olddragon2e.levels.${n}`;
}

Hooks.once("init", () => {
  registrarTema();
  registrarOpcoesDaOrdem();

  // As fichas são registradas no `ready` (ver lá). Aqui só a opção, que
  // precisa existir antes de ser lida.
  game.settings.register(ID, "fichasPadrao", {
    name: "Fichas Space Dragon como padrão",
    hint:
      "Todo personagem abre na Ficha Space Dragon e todo monstro na Ficha de Ameaça, " +
      "sem marcar ator por ator. Desligue numa mesa mista com o Star Dragon ou com " +
      "personagens de Old Dragon 2, e escolha a ficha no botão Sheet de cada ator.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
    requiresReload: true,
  });

  // Uma OPÇÃO, e não um fato consumado: trocar a tabela de modificadores muda
  // ataque, proteção, PV e jogadas de proteção de todo personagem do mundo.
  // Quem instalar o módulo só pelos compêndios pode não querer isso.
  game.settings.register(ID, "modificadores", {
    name: "Modificadores de atributo do Space Dragon",
    hint:
      "A ficha passa a usar a escala do Space Dragon — faixa neutra 10–11 e teto " +
      "no 29 — em vez da do Old Dragon 2. Afeta ataque, proteção, PV e JP. " +
      "Desligue para manter o cálculo original do sistema.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
    onChange: (v) => {
      aplicarModificadores(v);
      // As fichas abertas continuam mostrando o número velho até redesenhar.
      for (const app of Object.values(ui.windows)) app.render?.(false);
    },
  });
});

Hooks.once("ready", () => {
  // No `ready`, e não no `init`: no Foundry 13.351 o registro de fichas é uma
  // fila processada depois do `init` e do `setup`. No `init` a ficha do
  // sistema ainda não estava lá para ser estendida, e as fichas do módulo
  // nunca eram registradas. Ver ficha.js.
  const padrao = game.settings.get(ID, "fichasPadrao");
  registrarFicha(padrao);
  registrarFichaAmeaca(padrao);
  estendeNiveis();
  ligarTema();
  aplicarModificadores(game.settings.get(ID, "modificadores"));
  // O bônus de CP por nível (T4-1) é regra do livro, não opção: vale sempre
  // para quem usa a ficha do Space Dragon.
  aplicarCP();
  // A JP também é regra do livro: 1d20 + mod ≥ JP, e não d20 ≤ JP + mod.
  aplicarJP();
  ordenarHabilidades(true);
  ligarPainel();
  ligarCabecalho();
  ligarGrandezas();
  ligarMental();
  ligarDegraus();
  ligarOrdemNaFicha();
  // Por último: a aba de Poderes precisa estar desenhada para os rótulos de
  // Grandeza serem trocados.
  ligarRotulos();

  // A API que as macros do compêndio chamam. Fica aqui, e não dentro da macro,
  // para que atualizar o módulo atualize a regra: uma macro já arrastada para
  // a barra continua valendo, porque ela só chama isto.
  game.spacedragon = {
    teste: abrirTeste, rolar, preparar, TESTES,
    pv: rolarPV, critico: rolarCritico, multiplicadorCritico,
    compararEscalas, diagnostico, danosMortais, bonusDeCP, jp: rolarJP,
    jpAmeaca: rolarJPAmeaca, moral: rolarMoral,
    desativarRobos: abrirDesativar, rolarDesativar,
    reliquia: abrirReliquia, gerarReliquia, reliquiasDaCriatura: gerarDaCriatura, defeitoDeReliquia: rolarDefeito,
    ordem: abrirOrdem,
    alcance: orcamento, gastarAlcance: gastar, descansar,
    acertoCritico: () => rolarCriticoTabela("T7-4: Acerto Crítico", CRITICOS),
    falhaCritica: () => rolarCriticoTabela("T7-5: Falha Crítica", FALHAS),
    acertoCriticoNave: () => rolarCriticoTabela("T10-6: Acerto Crítico de Espaçonave", CRITICOS_NAVE),
    falhaCriticaNave: () => rolarCriticoTabela("T10-6: Falha Crítica de Espaçonave", FALHAS_NAVE),
  };

  console.log(`${ID} | ${TESTES.length} testes prontos, nível até o ${NIVEL_MAXIMO}º`);
});
